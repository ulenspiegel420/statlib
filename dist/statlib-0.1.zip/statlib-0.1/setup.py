from setuptools import setup

setup(
    name='statlib',
    version='0.1',
    packages=['statlib'],
    url='',
    license='',
    author='Vlad Koval',
    author_email='itsvlad.koval@gmail.com',
    description=''
)
