from abc import abstractmethod
import ipaddress
import urllib3
import configparser


def make_influx_stat(cfg_path):
    config = configparser.ConfigParser()
    config.read(cfg_path)

    host = config['DEFAULT'].get('HOST')
    port = config['DEFAULT'].get('PORT')
    db_name = config['DEFAULT'].get('DB')
    token = config['DEFAULT'].get('TOKEN')


class Stat:
    def __init__(self):
        self.__data = ''

    @abstractmethod
    def send(self, data):
        pass


class InfluxStat(Stat):
    def __init__(self, ip, db_name, port=8086, token=None):
        super().__init__()
        self.__token = token
        self.__ip = ipaddress.ip_address(ip)
        self.__port = port
        self.__db_name = db_name
        self.__url = "http://{}:{}/write?db={}".format(self.__ip, str(self.__port), self.__db_name)
        self.__headers = {'Authorization': self.__token}

    def send(self, data):
        http = urllib3.PoolManager()
        r = http.request('POST', self.__url, fields={'': data})
        pass
